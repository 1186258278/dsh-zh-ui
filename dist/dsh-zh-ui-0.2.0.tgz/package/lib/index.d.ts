import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type Finding, type RuleId } from './lint.js';
export declare const name = "zh-ui";
export declare const inject: string[];
export interface Config {
    registerSkill: boolean;
    injectProjectSpec: boolean;
    specFiles: string[];
    maxSpecChars: number;
    rules: RuleId[];
    spacingBasePx: number;
    allowedPx: number[];
    minLineHeight: number;
    maxFiles: number;
}
export declare const Config: z<Config>;
/** Split `---` YAML frontmatter from a SKILL.md body (only `name`/`description` are read). */
export declare function parseSkill(md: string): {
    name: string;
    description: string;
    content: string;
};
/** Read the project spec files under `cwd`, truncated, as one context block (or '' if none). */
export declare function readProjectSpec(cwd: string, files: readonly string[], maxChars: number): Promise<string>;
/** Run the lint over workspace paths; exported for tests and the CLI demo. */
export declare function runLint(cwd: string, paths: readonly string[], config: Config): Promise<Finding[]>;
export declare function renderFindings(findings: Finding[]): string;
export declare function apply(ctx: Context, config: Config): void;
