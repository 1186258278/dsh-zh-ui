/**
 * Static Chinese-UI lint. Pure functions over source text: no DOM, no network.
 * Inputs are HTML / CSS / JSX-like sources; findings carry 1-based line numbers.
 */
export type RuleId = 'hardcoded-color' | 'off-scale-px' | 'font-family-cjk' | 'cjk-latin-spacing' | 'cjk-punctuation' | 'cjk-line-height' | 'purple-gradient' | 'emoji-icon' | 'heading-subtitle' | 'filler-copy';
export declare const ALL_RULES: readonly RuleId[];
export interface LintOptions {
    /** Rules to run; defaults to all. */
    rules?: readonly RuleId[];
    /** Spacing/size px values must be multiples of this (or listed in allowedPx). */
    spacingBasePx?: number;
    /** Extra px values that are always allowed (e.g. 1, 2 for hairlines; token values). */
    allowedPx?: readonly number[];
    /** Colors allowed outside custom-property definitions (normalized lowercase hex or raw). */
    allowedColors?: readonly string[];
    /** Minimum unitless line-height for body text. */
    minLineHeight?: number;
}
export interface Finding {
    rule: RuleId;
    file: string;
    line: number;
    message: string;
}
/** Fonts that cover Simplified Chinese; one of them must appear in a font stack. */
export declare const CJK_FONTS: string[];
/** Parse a CSS color literal to [r,g,b] (0-255), or undefined. */
export declare function parseColor(raw: string): [number, number, number] | undefined;
/** Hue in degrees and HSL saturation (0-1). */
export declare function hueSat([r, g, b]: [number, number, number]): {
    hue: number;
    sat: number;
};
interface CssDecl {
    selector: string;
    prop: string;
    value: string;
    index: number;
    block: number;
}
/** Flatten innermost `selector { decls }` blocks; good enough for lint, not a full parser. */
export declare function cssDecls(css: string, baseIndex?: number): CssDecl[];
/** Lint one file. `kind` is inferred from the filename extension. */
export declare function lintSource(file: string, src: string, opts?: LintOptions): Finding[];
/** Collect color and px leaf values from a design.tokens.json-like object. */
export declare function tokenAllowances(tokens: unknown): {
    colors: string[];
    px: number[];
};
export declare function summarize(findings: Finding[]): Record<string, number>;
export {};
